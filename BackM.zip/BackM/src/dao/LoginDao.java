package dao;



import domain.Admin;

public interface LoginDao {
	public  Admin findAdmin(String adm_acc,String adm_pw);
}
