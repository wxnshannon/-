package dao;

import java.util.List;

import common.util.PageBean;

import domain.Admin;

public interface select_AdminDao {
	public  PageBean<Admin> findAdmin(String adm_acc, String adm_name,
			int page,int pageSize);
	public  PageBean<Admin> findall(int page,int pageSize);
	public  List<Admin> findall2();
	public  List<Admin> findByacc(String adm_acc);
	
}
