package dao;

import java.util.List;

import common.util.PageBean;

import domain.User;

public interface UserDao {
	public  PageBean<User> findByuser_acc(String user_acc,int page,int pageSize);
	public void UserDelete(String user_acc);
	public  PageBean<User> findUser(int page,int pageSize);
}
