package dao;

import java.util.HashMap;
import java.util.List;

import common.bean.PageInforBean;


public interface AdminDao {
	/**
	 * ��������Ա
	 * @param adm_acc
	 * @param adm_pw
	 * @param adm_name
	 * @param adm_sex
	 * @param adm_call
	 * @param adm_address
	 * @param adm_type
	 * @param adm_state
	 */
	public  void insertAdmin(String adm_acc, String adm_pw, String adm_name,String adm_sex,
			String adm_call,String adm_address,
			String adm_type, String adm_state);
	/**
	 * ɾ������Ա
	 * @param adm_acc
	 */
	public void AdminDelete(String adm_acc);
	/**
	 * �޸Ĺ���Ա��Ϣ
	 * @param adm_acc
	 * @param adm_pw
	 * @param adm_name
	 * @param adm_type
	 * @param adm_state
	 */
	public void UpdateAdmin(String adm_acc, String adm_pw, String adm_name,String adm_sex,
			String adm_call,String adm_address,
			String adm_type, String adm_state);
	
	public  boolean findAdmInsert(String adm_acc);
}


