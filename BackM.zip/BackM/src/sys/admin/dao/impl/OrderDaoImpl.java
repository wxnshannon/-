package sys.admin.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import sys.admin.bean.OrderBean;
import sys.admin.bean.OrderDetailBean;
import sys.admin.dao.OrderDao;
import sys.common.bean.PageInforBean;
import sym.common.util.ConnectionPool;
import sym.common.util.FieldCheck;

public class OrderDaoImpl implements OrderDao{

	Connection conn=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    
	@Override
	public PageInforBean<OrderBean> getOrder(String user, String order, int currentPage, int pageSize) {
		PageInforBean<OrderBean> page = null;        
		//1.��ȡ����
				conn=ConnectionPool.getConn();
				//2.����sql
				try {
				    int total=0;
					String sql = "select count(*) from T_order where order_useracc like ? and order_id like ?";				 
					ps = conn.prepareStatement(sql);
					ps.setString(1,"%" + FieldCheck.convertNullToEmpty(user) + "%");
					ps.setString(2,"%" + FieldCheck.convertNullToEmpty(order) + "%" );
				    rs = ps.executeQuery();
				    while (rs.next()) {
				      total=rs.getInt(1);
				    }
				    List<OrderBean> remarklist=new ArrayList<OrderBean>();
				    sql = "select top "+ pageSize+" * from T_order where order_useracc like ? and order_id like ? and order_id not in(select top "+(currentPage-1)*pageSize+" order_id from T_order  where order_useracc like ? and order_id like ?)";	
				    ps = conn.prepareStatement(sql);
				    ps.setString(1,"%" + FieldCheck.convertNullToEmpty(user) + "%");
					ps.setString(2,"%" + FieldCheck.convertNullToEmpty(order) + "%" );
					ps.setString(3,"%" + FieldCheck.convertNullToEmpty(user) + "%");
					ps.setString(4,"%" + FieldCheck.convertNullToEmpty(order) + "%" );
				    rs = ps.executeQuery();
				    while (rs.next()) {
				      String order_id = rs.getString(1);
				      String order_state = String.valueOf(rs.getInt(5));
				      String order_useracc = rs.getString(2);
				      String order_date = rs.getString(3);
				      String order_total = rs.getString(4);
				      String order_profit = rs.getString(6);
				      System.out.println("����"+order_id+order_state);
				      OrderBean bean = new OrderBean(order_id,order_state, order_useracc,order_date,order_total,order_profit);
				      remarklist.add(bean);
				    }
				    page=new PageInforBean<OrderBean>(currentPage,pageSize,total,remarklist);
				
				} catch (SQLException e) {
					e.printStackTrace();
				}finally{
					ConnectionPool.close(ps, rs, conn);
				}
				return page;
		
	}

	@Override
	public PageInforBean<OrderDetailBean> getOrderDetail(String order, int currentPage, int pageSize) {
		PageInforBean<OrderDetailBean> page = null;        
		//1.��ȡ����
				conn=ConnectionPool.getConn();
				System.out.println("order="+order);
				//2.����sql
				try {
				    int total=0;
				    String sql ="Create Table afew(od_id int,order_useracc varchar(15),od_orderid varchar(20),Pro_id varchar(20),Pro_num int,pro_name nvarchar(50),pro_unitprice money)";
				    ps = conn.prepareStatement(sql);
				    ps.executeUpdate();
				    sql = "Insert Into afew exec selectOrderDetail ?";
				    ps = conn.prepareStatement(sql); 
					ps.setString(1,order);
					ps.executeUpdate();
				    sql = "select count(*) from afew where od_orderid  = ?";				 
					ps = conn.prepareStatement(sql);
					ps.setString(1,order );
				    rs = ps.executeQuery();
				    while (rs.next()) {
				      total=rs.getInt(1);
				    }
				    List<OrderDetailBean> remarklist=new ArrayList<OrderDetailBean>();
				    sql = "select top "+ pageSize+" * from afew where od_orderid  = ? and od_id not in(select top "+(currentPage-1)*pageSize+" od_id from afew  where od_orderid = ? )";	
				    ps = conn.prepareStatement(sql);
				    ps.setString(1, order);
				    ps.setString(2, order);
				    rs = ps.executeQuery();
				    while (rs.next()) {
				      String order_useracc = rs.getString(2);
				      String od_orderid = rs.getString(3);
				      String Pro_id = rs.getString(4);
				      String Pro_num = String.valueOf(rs.getInt(5));
				      String Pro_name = rs.getString(6);
				      String Pro_unitprice = rs.getString(7);
				      OrderDetailBean bean = new OrderDetailBean(order_useracc,od_orderid, Pro_id,Pro_num,Pro_name,Pro_unitprice);
				      remarklist.add(bean);
				    }
				    sql ="drop Table afew";
				    ps = conn.prepareStatement(sql);
				    ps.executeUpdate();
				    page=new PageInforBean<OrderDetailBean>(currentPage,pageSize,total,remarklist);
				
				} catch (SQLException e) {
					e.printStackTrace();
				}finally{
					ConnectionPool.close(ps, rs, conn);
				}
				return page;
	}

	@Override
	public int updateOrder(String order,String total) {
		int result=0;
        //1.��ȡ����
		conn=ConnectionPool.getConn();
		//2.����sql
		String sql="update T_order set order_total = ? where order_id = ?";
		try {
			//3.��ռλ����ֵ
			ps=conn.prepareStatement(sql);	
			ps.setString(1,total);
			ps.setString(2,order);
			//4.����ִ��sql
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, rs, conn);
		}
		return result;
	}

	@Override
	public Double selectOrderTotal(String orderid) {
		Double total = (double) 0;
        //1.��ȡ����
		conn=ConnectionPool.getConn();
		//2.����sql
		String sql="select order_total from T_order  where order_id = ?";
		try {
			//3.��ռλ����ֵ
			ps=conn.prepareStatement(sql);	
			ps.setString(1,orderid);
			//4.����ִ��sql
			rs = ps.executeQuery();
			while(rs.next()) {
				total = rs.getDouble(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, rs, conn);
		}
		return total;
	}
	

}
