package sys.admin.bean;

public class OrderDetailBean {
	private String  order_useracc;
	private String od_orderid;
	private String Pro_id;
	private String Pro_num;
	private String pro_name;
	private String pro_unitprice;

	public OrderDetailBean(String order_useracc, String od_orderid,
			String pro_id, String pro_num,  String pro_name,
			String pro_unitprice) {
		super();
		this.order_useracc = order_useracc;
		this.od_orderid = od_orderid;
		Pro_id = pro_id;
		Pro_num = pro_num;
		this.pro_name = pro_name;
		this.pro_unitprice = pro_unitprice;
	}

	public String getPro_name() {
		return pro_name;
	}

	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}

	public String getPro_unitprice() {
		return pro_unitprice;
	}

	public void setPro_unitprice(String pro_unitprice) {
		this.pro_unitprice = pro_unitprice;
	}

	public String getOrder_useracc() {
		return order_useracc;
	}

	public void setOrder_useracc(String order_useracc) {
		this.order_useracc = order_useracc;
	}

	public String getOd_orderid() {
		return od_orderid;
	}

	public void setOd_orderid(String od_orderid) {
		this.od_orderid = od_orderid;
	}

	public String getPro_id() {
		return Pro_id;
	}

	public void setPro_id(String pro_id) {
		Pro_id = pro_id;
	}

	public String getPro_num() {
		return Pro_num;
	}

	public void setPro_num(String pro_num) {
		Pro_num = pro_num;
	}


	}
	
	
	
	


