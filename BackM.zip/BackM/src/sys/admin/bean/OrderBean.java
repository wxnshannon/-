package sys.admin.bean;

public class OrderBean {
	private String order_id;
	private String order_state;
	private String order_useracc;
	private String order_date;
	private String order_total;
	private String order_profit;
	
	public OrderBean(String order_id, String order_state, String order_useracc, String order_date, String order_total,
			String order_profit) {
		super();
		this.order_id = order_id;
		this.order_state = order_state;
		this.order_useracc = order_useracc;
		this.order_date = order_date;
		this.order_total = order_total;
		this.order_profit = order_profit;
	}

	public String getOrder_id() {
		return order_id;
	}

	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	public String getOrder_state() {
		return order_state;
	}

	public void setOrder_state(String order_state) {
		this.order_state = order_state;
	}

	public String getOrder_useracc() {
		return order_useracc;
	}

	public void setOrder_useracc(String order_useracc) {
		this.order_useracc = order_useracc;
	}

	public String getOrder_date() {
		return order_date;
	}

	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}

	public String getOrder_total() {
		return order_total;
	}

	public void setOrder_total(String order_total) {
		this.order_total = order_total;
	}

	public String getOrder_profit() {
		return order_profit;
	}

	public void setOrder_profit(String order_profit) {
		this.order_profit = order_profit;
	}
	
	
	
	

}
