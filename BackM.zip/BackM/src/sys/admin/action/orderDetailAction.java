package sys.admin.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.admin.dao.OrderDao;
import sys.admin.dao.impl.OrderDaoImpl;

public class orderDetailAction extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html; charset=UTF-8");
		String method = null;
		method = request.getParameter("method");
		String order = request.getParameter("order");		
		if("update".equals(method)){
			doUpdate(request, response);
		}
		response.sendRedirect(request.getContextPath()+"/orderDetail.jsp?order="+order);

	}
	
	public void doUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException 
	{
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		String total = request.getParameter("total");
		String order = request.getParameter("order");
		OrderDao dao = new OrderDaoImpl();
		int result = dao.updateOrder(order, total);
		if(result == 1){
			out.print("<script language='javascript'>alert(\'�����ɹ���\';</script>");
		}else{
			out.print("<script language='javascript'>alert(\'�����۸�������0��\';</script>");
		}
			

	}

}
