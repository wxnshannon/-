package sys.common.bean;
import java.util.List;

public class PageInforBean <T> {
	private int currentPage;
	private int pageSize;
	private int recordCount;
	private List<T> recordList;
	private int pageCount ;
	private int beginPageIndex;
	private int endPageIndex;
	
	public PageInforBean(int currentPage, int pageSize, int recordCount,
			List<T> recordList) {
		this.currentPage = currentPage;
		this.pageSize = pageSize;
		this.recordCount = recordCount;
		this.recordList = recordList;
		pageCount=(recordCount+pageSize-1)/pageSize;
		if(pageCount<=10)
		{
			beginPageIndex=1;
			endPageIndex=pageCount;
			
		}
		else
		{
			beginPageIndex=currentPage-4;
			endPageIndex=currentPage+5;
			if(beginPageIndex<1)
			{
				beginPageIndex=1;
				endPageIndex=10;
			}
			if(endPageIndex>pageCount)
			{
				beginPageIndex=pageCount-10+1;
				endPageIndex=pageCount;
			}
		}
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public List<T> getRecordList() {
		return recordList;
	}
	public void setRecordList(List<T> recordList) {
		this.recordList = recordList;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public int getBeginPageIndex() {
		return beginPageIndex;
	}
	public void setBeginPageIndex(int beginPageIndex) {
		this.beginPageIndex = beginPageIndex;
	}
	public int getEndPageIndex() {
		return endPageIndex;
	}
	public void setEndPageIndex(int endPageIndex) {
		this.endPageIndex = endPageIndex;
	}
	public int nextPage()
	{
		int nextPage=currentPage;
		nextPage++;
		if(nextPage>pageCount)
		{
			nextPage=pageCount;
		}
		return nextPage;
		}
	public int prePage()
	{
		int prePage=currentPage;
		prePage--;
		if(prePage<1)
		{
			prePage=1;
		}
		return prePage;
		}


}
