package servlet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import sym.common.util.ConnectionPool;



import dao.AdminDao;
import domain.Admin;

public class AdminDaoImpl implements AdminDao {
	
	public  void insertAdmin(String adm_acc, String adm_pw, String adm_name,String adm_sex,
			String adm_call,String adm_address,
			String adm_type, String adm_state){
		
	
		Connection conn=null;
		 PreparedStatement stmt=null;
		int rs=0;
		String sql="insert into T_admin(adm_acc,adm_password,adm_name,adm_sex,adm_call,adm_address,adm_type,adm_state) values (?,?,?,?,?,?,?,?)";
		
		try{
			conn=new ConnectionPool().getConn();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1,adm_acc);
			stmt.setString(2,adm_pw);
			stmt.setString(3,adm_name);
			stmt.setString(4,adm_sex);
			stmt.setString(5,adm_call);
			stmt.setString(6,adm_address);
			stmt.setString(7,adm_type);
			stmt.setString(8,adm_state);
			rs=stmt.executeUpdate();	
			System.out.println("-----"+1);
		} catch(Exception ex){
			ex.printStackTrace();
			
		}finally{
			try{
				
					stmt.close();
					conn.close();
				}catch(Exception ex){
					ex.printStackTrace();
				}
		}
		
	}

	public  boolean findAdmInsert(String adm_acc){

		boolean isInsert=true;
		List<Admin> admins = new ArrayList<Admin>();
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql="select *from T_admin where adm_acc=?";
		 
		
		try{
			conn=new ConnectionPool().getConn();
			
			System.out.println("con:"+conn);
			stmt=conn.prepareStatement(sql);
			stmt.setString(1,adm_acc);
			rs=stmt.executeQuery();
		
			while(rs.next()){
				
				String adm_acc1=rs.getString(1);
				if(adm_acc.equals(adm_acc1))
				{isInsert=false;}
				

			
			
		}
		
		} catch(Exception ex){
			ex.printStackTrace();
			
			
		}finally{
			try{
				rs.close();
					stmt.close();
					conn.close();
				}catch(Exception ex){
					ex.printStackTrace();
				}
		}
		return isInsert;
	}

	public void AdminDelete(String adm_acc) {
		Connection conn=null;
		PreparedStatement stmt=null;
		int rs=0;
		String sql="exec pr_deleteAdmin	 @adm_acc = ?";
		try{
			conn=new ConnectionPool().getConn();
			System.out.println("con"+conn);
			stmt=conn.prepareStatement(sql);			
			stmt.setString(1,adm_acc);
			rs=stmt.executeUpdate();
				
			System.out.println(rs);
		
	} catch(Exception ex){
		ex.printStackTrace();
		
	}finally{
		try{
			
				stmt.close();
				conn.close();
			}catch(Exception ex){
				ex.printStackTrace();
			}
	}

}


	public  void UpdateAdmin(String adm_acc, String adm_pw, String adm_name,String adm_sex,
			String adm_call,String adm_address,
			String adm_type, String adm_state){
		Connection conn=null;
		 PreparedStatement stmt=null;
		int rs=0;
		String sql=" update T_admin set adm_password=?,adm_name=?,adm_sex=?,adm_call=?,adm_address=?,adm_type=?,adm_state=? where adm_acc=?";
		try{
			conn=new ConnectionPool().getConn();
			stmt=conn.prepareStatement(sql);
			stmt.setString(8,adm_acc);
			stmt.setString(1,adm_pw);
			stmt.setString(2,adm_name);
			stmt.setString(3,adm_sex);
			stmt.setString(4,adm_call);
			stmt.setString(5,adm_address);
			stmt.setString(6,adm_type);
			stmt.setString(7,adm_state);
			rs=stmt.executeUpdate();	
			System.out.println("-----"+1);
		} catch(Exception ex){
			ex.printStackTrace();
			
		}finally{
			try{
				
					stmt.close();
					conn.close();
				}catch(Exception ex){
					ex.printStackTrace();
				}
		}

	}

	



	
}
	
