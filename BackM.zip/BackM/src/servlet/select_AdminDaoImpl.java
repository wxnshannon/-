package servlet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import sym.common.util.ConnectionPool;



import common.util.PageBean;


import dao.select_AdminDao;
import domain.Admin;




public class select_AdminDaoImpl implements select_AdminDao{
	
	public  PageBean<Admin> findAdmin(String adm_acc, String adm_name,
		int page,int pageSize){
		
		List<Admin> admins = new ArrayList<Admin>();
		PageBean<Admin> pageBean=null;
		
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql ="";		
		System.out.printf(".............."+adm_acc);
		if(!"".equals(adm_name)){
			System.out.println("------if---------"+adm_acc);
			sql="select * from T_admin where adm_acc=?";
		}
		if(null!=adm_name){
			sql="select * from T_admin where adm_name  like ?";
		}
	
		try{
			conn=new ConnectionPool().getConn();
			//�����ܼ�¼��
			int total=1;
			String sql1 = "select count(*) from T_user";
			
			stmt = conn.prepareStatement(sql1);
			rs = stmt.executeQuery();
			if(rs.next()) {
				total=rs.getInt(1);
			}
			System.out.println("con:"+conn);
			
			stmt=conn.prepareStatement(sql);
			
			if(!"".equals(adm_acc)){	
				
				stmt.setString(1,adm_acc);						
			}
			if(null!=adm_name){			
				stmt.setString(1,adm_name);	
				
				
			}
			
		
			rs=stmt.executeQuery();
			System.out.println("------����---------"+adm_acc);
			System.out.println("------����---------"+adm_name);
			
			while(rs.next()){
				
				String adm_acc1=rs.getString(1);
				String adm_pw1 =rs.getString(2);
				String adm_name1 =rs.getString(3);
				String adm_sex1 =rs.getString(4);
				String adm_call1=rs.getString(5);				
				String adm_address1=rs.getString(6);
				String adm_type1=rs.getString(7);				
				String adm_state1=rs.getString(8);
				
				
				Admin admin=new Admin();
				admin.setAdm_acc(adm_acc1);
				admin.setAdm_pw(adm_pw1);
				admin.setAdm_name(adm_name1);
				admin.setAdm_sex(adm_sex1);
				admin.setAdm_call(adm_call1);
				admin.setAdm_address(adm_address1);
				admin.setAdm_type(adm_type1);
				admin.setAdm_state(adm_state1);
				
				
				admins.add(admin);
				System.out.println("------admin---------"+admin.getAdm_acc());
			
			
		}
			pageBean =new PageBean<Admin>(page,pageSize,total,admins);
		} catch(Exception ex){
			ex.printStackTrace();
			
			
		}finally{
			try{
				rs.close();
					stmt.close();
					conn.close();
				}catch(Exception ex){
					ex.printStackTrace();
				}
		}
		return pageBean;
}

public  PageBean<Admin> findall(int page,int pageSize){
	
	PageBean<Admin> pageBean=null;
	
	List<Admin> admins = new ArrayList<Admin>();
	Connection conn=null;
	PreparedStatement stmt=null;
	ResultSet rs=null;
	String sql="select top " + pageSize + " * " +
			"from T_admin where " +
			" adm_acc not in (select top "+(page - 1) * pageSize+" adm_acc " +
			"from T_admin order by adm_acc asc)";
	 
	
	try{
		conn=new ConnectionPool().getConn();
		//�����ܼ�¼��
		int total=0;
		String sql1 = "select count(*) from T_admin";
		
		stmt = conn.prepareStatement(sql1);
		rs = stmt.executeQuery();
		if(rs.next()) {
			total=rs.getInt(1);
		}
		System.out.println("con:"+conn);
		stmt=conn.prepareStatement(sql);
		rs=stmt.executeQuery();
	
		while(rs.next()){
			
			String adm_acc1=rs.getString(1);
			String adm_pw1 =rs.getString(2);
			String adm_name1 =rs.getString(3);
			String adm_sex1 =rs.getString(4);
			String adm_call1=rs.getString(5);				
			String adm_address1=rs.getString(6);
			String adm_type1=rs.getString(7);				
			String adm_state1=rs.getString(8);
			
			
			Admin admin=new Admin();
			admin.setAdm_acc(adm_acc1);
			admin.setAdm_pw(adm_pw1);
			admin.setAdm_name(adm_name1);
			admin.setAdm_sex(adm_sex1);
			admin.setAdm_call(adm_call1);
			admin.setAdm_address(adm_address1);
			admin.setAdm_type(adm_type1);
			admin.setAdm_state(adm_state1);
			
			
			admins.add(admin);

		
		
	}
		pageBean =new PageBean<Admin>(page,pageSize,total,admins);
	} catch(Exception ex){
		ex.printStackTrace();
		
		
	}finally{
		try{
			rs.close();
				stmt.close();
				conn.close();
			}catch(Exception ex){
				ex.printStackTrace();
			}
	}
	return pageBean;
}
	

public  List<Admin> findall2(){

	
	List<Admin> admins = new ArrayList<Admin>();
	Connection conn=null;
	PreparedStatement stmt=null;
	ResultSet rs=null;
	String sql="select *from T_admin";
	 
	
	try{
		conn=new ConnectionPool().getConn();
		
		System.out.println("con:"+conn);
		stmt=conn.prepareStatement(sql);
		rs=stmt.executeQuery();
	
		while(rs.next()){
			
			
			String adm_acc1=rs.getString(1);
			String adm_pw1 =rs.getString(2);
			String adm_name1 =rs.getString(3);
			String adm_sex1 =rs.getString(4);
			String adm_call1=rs.getString(5);				
			String adm_address1=rs.getString(6);
			String adm_type1=rs.getString(7);				
			String adm_state1=rs.getString(8);
			
			
			Admin admin=new Admin();
			admin.setAdm_acc(adm_acc1);
			admin.setAdm_pw(adm_pw1);
			admin.setAdm_name(adm_name1);
			admin.setAdm_sex(adm_sex1);
			admin.setAdm_call(adm_call1);
			admin.setAdm_address(adm_address1);
			admin.setAdm_type(adm_type1);
			admin.setAdm_state(adm_state1);
			admins.add(admin);

		
		
	}
	
	} catch(Exception ex){
		ex.printStackTrace();
		
		
	}finally{
		try{
			rs.close();
				stmt.close();
				conn.close();
			}catch(Exception ex){
				ex.printStackTrace();
			}
	}
	return admins;
}
	

public  List<Admin> findByacc(String adm_acc){

	
	List<Admin> admins = new ArrayList<Admin>();
	Connection conn=null;
	PreparedStatement stmt=null;
	ResultSet rs=null;
	String sql="select *from T_admin where adm_acc=?";
	 
	
	try{
		conn=new ConnectionPool().getConn();
		
		System.out.println("con:"+conn);
		stmt=conn.prepareStatement(sql);
		stmt.setString(1,adm_acc);
		rs=stmt.executeQuery();
	
		while(rs.next()){
			
			
			String adm_acc1=rs.getString(1);
			String adm_pw1 =rs.getString(2);
			String adm_name1 =rs.getString(3);
			String adm_sex1 =rs.getString(4);
			String adm_call1=rs.getString(5);				
			String adm_address1=rs.getString(6);
			String adm_type1=rs.getString(7);				
			String adm_state1=rs.getString(8);
			
			
			Admin admin=new Admin();
			admin.setAdm_acc(adm_acc1);
			admin.setAdm_pw(adm_pw1);
			admin.setAdm_name(adm_name1);
			admin.setAdm_sex(adm_sex1);
			admin.setAdm_call(adm_call1);
			admin.setAdm_address(adm_address1);
			admin.setAdm_type(adm_type1);
			admin.setAdm_state(adm_state1);
			admins.add(admin);

		
		
	}
	
	} catch(Exception ex){
		ex.printStackTrace();
		
		
	}finally{
		try{
			rs.close();
				stmt.close();
				conn.close();
			}catch(Exception ex){
				ex.printStackTrace();
			}
	}
	return admins;
}


}
	
