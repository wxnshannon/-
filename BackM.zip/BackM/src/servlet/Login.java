package servlet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import sym.common.util.ConnectionPool;




import dao.LoginDao;
import domain.Admin;


public class Login implements LoginDao{

	public  Admin findAdmin(String adm_acc,String adm_pw){
		Connection con=null;
		PreparedStatement stmt=null;
		ResultSet i=null;
		Admin pat=new Admin();
		int a=0;
		String sql="select * from  admin where adm_state='1' and adm_acc=? and adm_password=?";
		try{
			con=new ConnectionPool().getConn();
			stmt=con.prepareStatement(sql);
			stmt.setString(1, adm_acc);
			stmt.setString(2,adm_pw); 
			i=stmt.executeQuery();
			while(i.next()){
				pat.setAdm_acc(i.getString(1));
				pat.setAdm_pw(i.getString(2));
			
				pat.setAdm_type(i.getString(3));
				pat.setAdm_state(i.getString(4));
				
				
			}
			}catch(Exception ex){
				ex.printStackTrace();
			}finally{
				try{
					if(i!=null)
						i.close();
				}catch(Exception ex){
					ex.printStackTrace();
					
				}finally{
					try{
						if(stmt!=null)
							stmt.close();
					}catch(Exception ex){
						ex.printStackTrace();
						
					}finally{
						try{
							if(con!=null)
								con.close();
						}catch(Exception ex){
							ex.printStackTrace();
							
						}
					}
				}
				
					
			}
		return pat;
	}

}
