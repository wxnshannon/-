package servlet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import sym.common.util.ConnectionPool;


import common.util.PageBean;

import dao.UserDao;
import domain.User;

public class UserDaoImpl implements UserDao{
	public  PageBean<User> findByuser_acc(String user_acc,int page,int pageSize){
		
		PageBean<User> pageBean=null;
		
		List<User> users = new ArrayList<User>();
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql ="select * from  T_user where user_acc=?";		
		
		try{
			conn=new ConnectionPool().getConn();
			//�����ܼ�¼��
			int total=0;
			String sql1 = "select count(*) from T_user";
			
			stmt = conn.prepareStatement(sql1);
			rs = stmt.executeQuery();
			if(rs.next()) {
				total=rs.getInt(1);
			}
					
			System.out.println("con:"+conn);
			stmt=conn.prepareStatement(sql);
			
			stmt.setString(1,user_acc);
			
			rs=stmt.executeQuery();
			
			while(rs.next()){
				String user_acc1=rs.getString(1);
				String user_pw =rs.getString(2);
				String user_soname =rs.getString(3);
				String user_name=rs.getString(4);	
				String user_sex=rs.getString(5);		
				String user_mobile=rs.getString(6);
				String user_address=rs.getString(7);
				
				
				
				User user=new User();
				user.setUser_acc(user_acc1);
				user.setUser_pw(user_pw);
				user.setUser_soname(user_soname);
				user.setUser_name(user_name);
				user.setUser_sex(user_sex);
				user.setUser_mobile(user_mobile);
				user.setUser_address(user_address);
				
				
				
				users.add(user);
	
			
			}
			pageBean =new PageBean<User>(page,pageSize,total,users);
		} catch(Exception ex){
			ex.printStackTrace();
			
			
		}finally{
			try{
				rs.close();
					stmt.close();
					conn.close();
				}catch(Exception ex){
					ex.printStackTrace();
				}
		}
		return pageBean;

		
	}
	public void UserDelete(String user_acc) {
		Connection conn=null;
		PreparedStatement stmt=null;
		int rs=0;
		String sql="exec pr_deleteUser	 @user_acc = ?";
		try{
			conn=new ConnectionPool().getConn();
			System.out.println("con"+conn);
			stmt=conn.prepareStatement(sql);			
			stmt.setString(1,user_acc);
			rs=stmt.executeUpdate();
				
			System.out.println(rs);
		
	} catch(Exception ex){
		ex.printStackTrace();
		
	}finally{
		try{
			
				stmt.close();
				conn.close();
			}catch(Exception ex){
				ex.printStackTrace();
			}
	}

}
	public  PageBean<User> findUser(int page,int pageSize){
		PageBean<User> pageBean=null;
		
		List<User> users = new ArrayList<User>();
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;

		String sql = "select top " + pageSize + " * " +
				"from T_user where " +
				" user_acc not in (select top "+(page - 1) * pageSize+" user_acc " +
				"from T_user)";
		try{
			conn=new ConnectionPool().getConn();
			//�����ܼ�¼��
			int total=0;
			String sql1 = "select count(*) from T_user";
			
			stmt = conn.prepareStatement(sql1);
			rs = stmt.executeQuery();
			if(rs.next()) {
				total=rs.getInt(1);
			}
			System.out.println(total);
			System.out.println("con:"+conn);
			stmt=conn.prepareStatement(sql);
			rs=stmt.executeQuery();
			
			while(rs.next()){
				String user_acc1=rs.getString(1);
				String user_pw =rs.getString(2);
				String user_soname =rs.getString(3);
				String user_name=rs.getString(4);	
				String user_sex=rs.getString(5);		
				String user_mobile=rs.getString(6);
				String user_address=rs.getString(7);
				
				
				
				User user=new User();
				user.setUser_acc(user_acc1);
				user.setUser_pw(user_pw);
				user.setUser_soname(user_soname);
				user.setUser_name(user_name);
				user.setUser_sex(user_sex);
				user.setUser_mobile(user_mobile);
				user.setUser_address(user_address);
				
				
				
				users.add(user);
			
			}
			pageBean =new PageBean<User>(page,pageSize,total,users);
		} catch(Exception ex){
			ex.printStackTrace();
			
			
		}finally{
			try{
				rs.close();
					stmt.close();
					conn.close();
				}catch(Exception ex){
					ex.printStackTrace();
				}
		}
		return pageBean;
		
	}
	
	

}
