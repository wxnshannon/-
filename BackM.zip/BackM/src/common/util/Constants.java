package common.util;


public class Constants {
	public static final String SALT="haha";
	
	public static final int PAGE_NUM=7;
	
	public static final int PAGE_NUM1=5;
}
