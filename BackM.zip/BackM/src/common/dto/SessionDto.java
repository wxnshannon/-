package common.dto;

public class SessionDto {
	private String user_acc;//�û��˺�
	private String user_pw;//�û�����
	private String user_soname;//�û��罻����
	private String user_name;//��ʵ����
	private String user_mobile;//�绰
	private String user_address;//��ַ


	public void reset() {

	}


	public String getUser_acc() {
		return user_acc;
	}
	public void setUser_acc(String user_acc) {
		this.user_acc = user_acc;
	}
	public String getUser_pw() {
		return user_pw;
	}
	public void setUser_pw(String user_pw) {
		this.user_pw = user_pw;
	}
	public String getUser_soname() {
		return user_soname;
	}
	public void setUser_soname(String user_soname) {
		this.user_soname = user_soname;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_mobile() {
		return user_mobile;
	}
	public void setUser_mobile(String user_mobile) {
		this.user_mobile = user_mobile;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	
	
}

