package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlet.AdminDaoImpl;
import servlet.UserDaoImpl;
import dao.AdminDao;
import dao.UserDao;

public class UserDelete extends HttpServlet {


	 
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


		doPost(request, response);
	 }
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url=request.getContextPath()+"/User.jsp";

		request.setCharacterEncoding("UTF-8");
		String user_acc = request.getParameter("user_acc");		
		UserDao user = new UserDaoImpl();
		user.UserDelete(user_acc);
		
		response.sendRedirect(url);
	}
	

}
