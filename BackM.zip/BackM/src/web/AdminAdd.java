package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlet.AdminDaoImpl;

import dao.AdminDao;

public class AdminAdd extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		boolean isinsert;
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out=response.getWriter();
		request.setCharacterEncoding("UTF-8");
		String adm_acc = request.getParameter("adm_acc");
		String adm_pw = request.getParameter("adm_pw");
		String adm_name = request.getParameter("adm_name");
		String adm_sex = request.getParameter("adm_sex");
		String adm_call = request.getParameter("adm_call");
		String adm_address = request.getParameter("adm_address");
		String adm_type = request.getParameter("adm_type");
		String adm_state = request.getParameter("adm_state");
		
		String url1= request.getContextPath() +"/manage.jsp";		
		AdminDao admin = new AdminDaoImpl();
		isinsert = admin.findAdmInsert(adm_acc);
		if(isinsert==true)
			{
			admin.insertAdmin(adm_acc,adm_pw,adm_name,adm_sex,adm_call,adm_address,adm_type,adm_state);
			response.sendRedirect(url1);
			
			}
		else
			out.println("�ù���Ա�˺��Ѵ���");	
		out.print("<html><body><a href=./manage.jsp>���ع���Աҳ��</a></body></html>");	
		
		}
		
	
}