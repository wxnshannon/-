package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlet.Login;

import dao.LoginDao;
import domain.Admin;

public class AdminServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url1= request.getContextPath() +"/manage.jsp";
		String url2= request.getContextPath() +"/proInfo.jsp";
		String url3= request.getContextPath() +"/index.jsp";
		String url4= request.getContextPath() +"/aLogin.jsp";
		request.setCharacterEncoding("UTF-8");
		String a_acc= request.getParameter("username");
		String a_pw=request.getParameter("password");
		LoginDao dao=new Login();
		
		Admin  s=dao.findAdmin(a_acc,a_pw);
		if(a_acc.equals(s.getAdm_acc())&&a_pw.equals(s.getAdm_pw())){			
			if ("1".equals(s.getAdm_type())) {
				System.out.println(s.getAdm_type());
				response.sendRedirect(url1);
			} else if ("2".equals(s.getAdm_type())) {
				response.sendRedirect(url2);
			} else if ("3".equals(s.getAdm_type())) {
			
				response.sendRedirect(url3);
			}	
		}else{
				response.sendRedirect(url4);
			}
	}
	
}