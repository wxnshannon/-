package domain;

public class Admin{
	private String adm_acc;//����Ա�˺�
	private String adm_pw;//����Ա����
	private String adm_name;//����Ա����
	private String adm_sex;//����Ա�Ա�
	private String adm_call;//����Ա�绰
	private String adm_address;//����Ա��ַ
	private String adm_type;//����Ա����
	private String adm_state;//����Ա״̬[��Ч����Ч]
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getAdm_acc() {
		return adm_acc;
	}
	public void setAdm_acc(String adm_acc) {
		this.adm_acc = adm_acc;
	}
	public String getAdm_pw() {
		return adm_pw;
	}
	public void setAdm_pw(String adm_pw) {
		this.adm_pw = adm_pw;
	}
	public String getAdm_name() {
		return adm_name;
	}
	public void setAdm_name(String adm_name) {
		this.adm_name = adm_name;
	}
	public String getAdm_type() {
		return adm_type;
	}
	public void setAdm_type(String adm_type) {
		this.adm_type = adm_type;
	}
	public String getAdm_state() {
		return adm_state;
	}
	public void setAdm_state(String adm_state) {
		this.adm_state = adm_state;
	}

	public String getAdm_sex() {
		return adm_sex;
	}

	public void setAdm_sex(String adm_sex) {
		this.adm_sex = adm_sex;
	}

	public String getAdm_call() {
		return adm_call;
	}

	public void setAdm_call(String adm_call) {
		this.adm_call = adm_call;
	}

	public String getAdm_address() {
		return adm_address;
	}

	public void setAdm_address(String adm_address) {
		this.adm_address = adm_address;
	}
}
