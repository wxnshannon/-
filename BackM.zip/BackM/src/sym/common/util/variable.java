package sym.common.util;

public class variable {
	public static int PAGECOUNT = 5;
}
