package sym.common.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;

/**
 * ���ݿ����ӷ�װ��
 *
 */
public class DBUtils {
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;

	public int update(String sql, Object... objects) {
		int result = 0;
		try {
			connection = ConnectionPool.getConn();

			preparedStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			//��preparedStatementװ������
			for (int i = 1; i <= objects.length; i++) {
				preparedStatement.setObject(i, objects[i - 1]);
			}
			result = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	//��RowSet��װ����
	public CachedRowSet select(String sql, Object... objects) {
		// ��ʼ������������
		CachedRowSet cachedRowSet = null;
		try {
			connection = ConnectionPool.getConn();
			RowSetFactory factory = RowSetProvider.newFactory();
			cachedRowSet = factory.createCachedRowSet();

			preparedStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE,// ResultSet.TYPE_SCROLL_SENSITIVE�����ý�������������򱨴�
					ResultSet.CONCUR_READ_ONLY);
			
			for (int i = 1; i <= objects.length; i++) {
				preparedStatement.setObject(i, objects[i - 1]);
			}
			resultSet = preparedStatement.executeQuery();
			//ʹ��ResultSetװ��RowSet
			cachedRowSet.populate(resultSet);
			//װ����ϣ��ر����ݿ�����
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cachedRowSet;
	}
	//ʹ��RowSet���з�ҳ
	public CachedRowSet queryByPage(String sql, int pageSize, int page, Object... objects) {
		CachedRowSet cachedRowSet = null;
		try {
			connection = ConnectionPool.getConn();
			preparedStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			for (int i = 1; i <= objects.length; i++) {
				preparedStatement.setObject(i, objects[i - 1]);
			}
			resultSet = preparedStatement.executeQuery();

			RowSetFactory rowSetFactory = RowSetProvider.newFactory();
			cachedRowSet = rowSetFactory.createCachedRowSet();
			//������ֵ����
			if (pageSize < 1)
				pageSize = 1;
			if (page < 1)
				page = 1;
			cachedRowSet.setPageSize(pageSize);
			//ָ���ӵ�(page - 1) * pageSize + 1����¼��ʼװ��һҳ�Ĵ�С
			//Ҫ�ȵ���setPageSize�趨��ҳ�Ĵ�С�������Ĭ�ϴ�ָ����¼��ʼװ�����ResultSet�����һ����¼
			cachedRowSet.populate(resultSet, (page - 1) * pageSize + 1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return cachedRowSet;

	}

	public void close() throws Exception {
		if (resultSet != null) {
			resultSet.close();
		}
		if (preparedStatement != null) {
			preparedStatement.close();
		}
		if (connection != null) {
			connection.close();
		}

	}

}
