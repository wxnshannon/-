package sym.product.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sym.common.bean.PageInfo;
import sym.product.bean.ProductBean;
import sym.product.dao.*;
import sym.product.dao.impl.ProductDaoImpl;


public class ProductAction extends HttpServlet {
	private final static String PAGESIZE = "5";
	ProductDao dao = new ProductDaoImpl();

	/**
	 * doPost����
	 */
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
		if ("insertProduct".equals(method)) {
			insertProduct(request, response);
		} else if ("productinfo".equals(method)) {
			productList(request, response);
		} else if ("deleteproduct".equals(method)) {
			deleteProduct(request, response);
		} else if ("selectproduct".equals(method)) {
			selectProduct(request, response);
		} else if ("updateproduct".equals(method)) {
			updateProduct(request, response);
		} else if("checkproduct".equals(method)){
			checkProduct(request,response);
		}
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * ������Ʒ
	 * 
	 * @param request
	 * @param response
	 */
	private void insertProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductBean productBean = new ProductBean();
		request.setCharacterEncoding("UTF-8");
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		String pro_id = request.getParameter("pro_id");
		String pro_name = request.getParameter("pro_name");
		String pro_unitprice = request.getParameter("pro_unitprice");
		String pro_purchase = request.getParameter("pro_purchase");
		String pro_type = request.getParameter("pro_type");
		String pro_describe = request.getParameter("pro_describe");
		String pro_image = request.getParameter("pro_image");
		String pro_date = request.getParameter("pro_date");
		if (pro_date == null)
			pro_date = date.format(new Date());
		String pro_thumbnail = request.getParameter("pro_thumbnail");
		String pro_inbentory = request.getParameter("pro_inbentory");
		productBean.setPro_id(pro_id);
		productBean.setPro_name(pro_name);
		productBean.setPro_unitprice(pro_unitprice);
		productBean.setPro_purchase(pro_purchase);
		productBean.setPro_type(pro_type);
		productBean.setPro_date(pro_date);
		productBean.setPro_image(pro_image);
		productBean.setPro_thumbnail(pro_thumbnail);
		productBean.setPro_inbentory(pro_inbentory);
		productBean.setPro_describe(pro_describe);

		new ProductDaoImpl().insertProduct(productBean);

		request.getRequestDispatcher("proinsert.jsp").forward(request, response);
	}
	/**
	 * ��ʾ��Ʒ�б�
	 * 
	 * @param request
	 * @param response
	 */
	private void productList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String type = request.getParameter("type");
		String state = request.getParameter("state");
		if ("99".equals(type)) {
			type = "";
		}
		if ("99".equals(state)) {
			state = "";
		}
		String date = request.getParameter("dateP");
		String name = request.getParameter("name");
		// ��ȡcurrPage��pageSize
		String currPage = request.getParameter("currPage");
		if (currPage == null) {
			currPage = "1";
		}
		String pageSize = request.getParameter("pageSize");
		if (pageSize == null) {
			pageSize = PAGESIZE;
		}
		int iCurrPage = 1;
		int iPageSize = Integer.parseInt(PAGESIZE);
		try {
			iCurrPage = Integer.parseInt(currPage);
			iPageSize = Integer.parseInt(pageSize);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (iCurrPage < 1) {
			iCurrPage = 1;
		}
		if (iPageSize < 1) {
			iPageSize = Integer.parseInt(PAGESIZE);
		}

		ProductDao dao = new ProductDaoImpl();
		// ��ʵ��ByPage������Ͳ���������
		List<ProductBean> result = dao.getProductAll(iCurrPage, iPageSize, type, state, date, name);
		// ��ҳ���ļ���
		// ��¼������
		int totalCount = dao.getProductCount(type, state, date, name);
		// ������ҳ��
		int totalPage = countTotalPage(totalCount, iPageSize);

		PageInfo<ProductBean> pageInfo = new PageInfo<ProductBean>();
		pageInfo.setList(result);
		pageInfo.setCurrPage(iCurrPage);
		pageInfo.setPageSize(iPageSize);
		pageInfo.setTotalCount(totalCount);
		pageInfo.setTotalPage(totalPage);
		request.setAttribute("pageModel", pageInfo);
		request.getRequestDispatcher("proList.jsp").forward(request, response);

	}

	private int countTotalPage(int totalCount, int pageSize) {
		return totalCount % pageSize > 0 ? totalCount / pageSize + 1 : totalCount / pageSize;
	}

	private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductDao productDao = new ProductDaoImpl();
		String id = request.getParameter("id");
		ProductBean productBean = productDao.getProductBeanById(id);
		PrintWriter writer = response.getWriter();
		if (productBean != null) {
			int result = productDao.deleteById(id);
			writer.print(result);
		} else {
			writer.print("error");
		}
	}

	private void selectProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductDao productDao = new ProductDaoImpl();
		String id = request.getParameter("id");
		ProductBean productBean = productDao.getProductBeanById(id);
		if (productBean != null) {
			request.getSession().setAttribute("nowProduct", productBean);
			response.sendRedirect("proupdate.jsp");
		}
	}
	private void checkProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductDao productDao = new ProductDaoImpl();
		String id = request.getParameter("id");
		ProductBean productBean = productDao.getProductBeanById(id);
		PrintWriter writer = response.getWriter();
		if(productBean==null){
			writer.print("0");
		}else{
			writer.print("1");
		}
	}
	
	private void updateProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductBean productBean = new ProductBean();
		request.setCharacterEncoding("UTF-8");
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		String pro_id = request.getParameter("pro_id");
		String pro_name = request.getParameter("pro_name");
		String pro_unitprice = request.getParameter("pro_unitprice");
		String pro_purchase = request.getParameter("pro_purchase");
		String pro_type = request.getParameter("pro_type");
		String pro_describe = request.getParameter("pro_describe");
		String pro_image = request.getParameter("pro_image");
		String pro_date = request.getParameter("pro_date");
		String pro_state = request.getParameter("pro_state");
		if (pro_date == null)
			pro_date = date.format(new Date());
		String pro_thumbnail = request.getParameter("pro_thumbnail");
		String pro_inbentory = request.getParameter("pro_inbentory");
		productBean.setPro_id(pro_id);
		productBean.setPro_name(pro_name);
		productBean.setPro_unitprice(pro_unitprice);
		productBean.setPro_purchase(pro_purchase);
		productBean.setPro_type(pro_type);
		productBean.setPro_state(pro_state);
		productBean.setPro_date(pro_date);
		productBean.setPro_image(pro_image);
		productBean.setPro_thumbnail(pro_thumbnail);
		productBean.setPro_inbentory(pro_inbentory);
		productBean.setPro_describe(pro_describe);

		int result = new ProductDaoImpl().updateProduct(productBean);
		PrintWriter writer = response.getWriter();
		writer.print(result);
	}
}
