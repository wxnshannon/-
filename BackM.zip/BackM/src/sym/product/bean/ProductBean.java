package sym.product.bean;

public class ProductBean {
	private String pro_id; //��ƷID
	private String pro_name; //��Ʒ��
	private String pro_unitprice; //����
	private String pro_purchase; //��Ʒ����
	private String pro_type; //��Ʒ����
	private String pro_describe; //��Ʒ����
	private String pro_image; //��Ʒͼ���ַ
	private String pro_date; //��Ʒ��������
	private String pro_thumbnail; //��Ʒ����ͼ��ַ
	private String pro_inbentory; //��Ʒ���
	private String pro_state; //��Ʒ״̬

	public ProductBean(String pro_id, String pro_name, String pro_unitprice,
			String pro_purchase, String pro_type, String pro_describe,
			String pro_image, String pro_date, String pro_thumbnail,
			String pro_inbentory, String pro_state) {
		super();
		this.pro_id = pro_id;
		this.pro_name = pro_name;
		this.pro_unitprice = pro_unitprice;
		this.pro_purchase = pro_purchase;
		this.pro_type = pro_type;
		this.pro_describe = pro_describe;
		this.pro_image = pro_image;
		this.pro_date = pro_date;
		this.pro_thumbnail = pro_thumbnail;
		this.pro_inbentory = pro_inbentory;
		this.pro_state = pro_state;
	}
	public ProductBean() {
		
	}
	public String getPro_id() {
		return pro_id;
	}
	public void setPro_id(String pro_id) {
		this.pro_id = pro_id;
	}
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public String getPro_unitprice() {
		return pro_unitprice;
	}
	public void setPro_unitprice(String pro_unitprice) {
		this.pro_unitprice = pro_unitprice;
	}
	public String getPro_purchase() {
		return pro_purchase;
	}
	public void setPro_purchase(String pro_purchase) {
		this.pro_purchase = pro_purchase;
	}
	public String getPro_type() {
		return pro_type;
	}
	public void setPro_type(String pro_type) {
		this.pro_type = pro_type;
	}
	public String getPro_describe() {
		return pro_describe;
	}
	public void setPro_describe(String pro_describe) {
		this.pro_describe = pro_describe;
	}
	public String getPro_image() {
		return pro_image;
	}
	public void setPro_image(String pro_image) {
		this.pro_image = pro_image;
	}
	public String getPro_date() {
		return pro_date;
	}
	public void setPro_date(String pro_date) {
		this.pro_date = pro_date;
	}
	public String getPro_thumbnail() {
		return pro_thumbnail;
	}
	public void setPro_thumbnail(String pro_thumbnail) {
		this.pro_thumbnail = pro_thumbnail;
	}
	public String getPro_inbentory() {
		return pro_inbentory;
	}
	public void setPro_inbentory(String pro_inbentory) {
		this.pro_inbentory = pro_inbentory;
	}
	public String getPro_state() {
		return pro_state;
	}
	public void setPro_state(String pro_state) {
		this.pro_state = pro_state;
	}
	
}
