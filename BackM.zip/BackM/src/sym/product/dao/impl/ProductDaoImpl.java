package sym.product.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import sym.common.util.DBUtils;
import sym.product.bean.ProductBean;
import sym.product.dao.ProductDao;

public class ProductDaoImpl implements ProductDao {

	public int insertProduct(ProductBean productBean) {
		int rt_msg = 0;
		DBUtils dbUtils = new DBUtils();
		String pro_id = productBean.getPro_id();
		String pro_name = productBean.getPro_name();
		String pro_unitprice = productBean.getPro_unitprice();
		String pro_purchase = productBean.getPro_purchase();
		String pro_type = productBean.getPro_type();
		String pro_describe = productBean.getPro_describe();
		String pro_image = productBean.getPro_image();
		String pro_date = productBean.getPro_date();
		String pro_thumbnail = productBean.getPro_thumbnail();
		String pro_inbentory = productBean.getPro_inbentory();
		String sql = "insert into T_product (pro_id, pro_name,pro_unitprice, pro_purchase, pro_type, pro_describe,pro_image,pro_date,pro_thumbnail,pro_inbentory)"
				+ "values (?,?,?,?,?,?,?,?,?,?)";

		rt_msg = dbUtils.update(sql, pro_id,pro_name,pro_unitprice,pro_purchase,pro_type,pro_describe,pro_image,pro_date,pro_thumbnail,pro_inbentory);
		return rt_msg;
	}

	public int updateProduct(ProductBean productBean) {
		String pro_id = productBean.getPro_id();
		String pro_name = productBean.getPro_name();
		String pro_unitprice = productBean.getPro_unitprice();
		String pro_purchase = productBean.getPro_purchase();
		String pro_type = productBean.getPro_type();
		String pro_describe = productBean.getPro_describe();
		String pro_image = productBean.getPro_image();
		String pro_date = productBean.getPro_date();
		String pro_thumbnail = productBean.getPro_thumbnail();
		String pro_inbentory = productBean.getPro_inbentory();
		String pro_state = productBean.getPro_state();
		DBUtils dbUtils = new DBUtils();
		String sql = "UPDATE T_product SET pro_name =?,pro_unitprice=?,pro_purchase =?,pro_state=?,pro_type =?,pro_describe =?,pro_image=?,pro_date=?,pro_thumbnail =?,pro_inbentory =? WHERE pro_id =?";
		int result = dbUtils.update(sql, pro_name,pro_unitprice,pro_purchase,pro_state,pro_type,pro_describe,pro_image,pro_date,pro_thumbnail,pro_inbentory,pro_id);
		
		return result;
	}


	
	public List<ProductBean> getProductAll(int iCurrPage, int iPageSize, String type, String state, String date,
			String name) {
		DBUtils dbUtils = new DBUtils();
		List<ProductBean> result = new ArrayList<ProductBean>();
		String sql = "select * from T_product where 1=1";//1=1���棬�����������if���SQL���
		if(type!=null && type!=""){
			sql += " and pro_type = "+ type;
		}
		if(state!=null && state!=""){
			sql += " and pro_state = " + state;
		}
		if(date!=null && date!=""){
			sql += " and pro_date like '" + date + "%'";
		}
		if(name!=null && name!=""){
			name = "%" + name +"%";
			sql += " and pro_name like '"+name+"'";
		}
		System.out.println(sql);
		ResultSet resultSet = dbUtils.queryByPage(sql, iPageSize, iCurrPage);
		try {
//			System.out.println(resultSet.getRow());
			while(resultSet.next()){
				ProductBean productBean = handleData(resultSet);
				result.add(productBean);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public int getProductCount(String type, String state, String date, String name) {
		DBUtils dbUtils = new DBUtils();
		String sql = "select count(*) as count from T_product where 1=1";
		if(type!=null && type!=""){
			sql += " and pro_type = "+ type;
		}
		if(state!=null && state!=""){
			sql += " and pro_state = " + state;
		}
		if(date!=null && date!=""){
			sql += " and pro_date like '" + date + "%'";
		}
		if(name!=null && name!=""){
			name = "%" + name +"%";
			sql += " and pro_name like '"+name+"'";
		}
		ResultSet resultSet = dbUtils.select(sql);
		int result = 0;
		try {
			while(resultSet.next()){
				result = resultSet.getInt("count");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result ;
	}


	@Override
	public List<String> getProductType() {
		DBUtils dbUtils = new DBUtils();
		List<String> result = new ArrayList<String>();
		String sql = "select pro_type,count(*) as count from T_product group by pro_type";
		ResultSet resultSet = dbUtils.select(sql);
		try {
			while(resultSet.next()){
				String s = resultSet.getInt("pro_type")+"";
				result.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;		
	}

	@Override
	public List<String> getProductState() {
		DBUtils dbUtils = new DBUtils();
		List<String> result = new ArrayList<String>();
		String sql = "select pro_state,count(*) as count from T_product group by pro_state";
		ResultSet resultSet = dbUtils.select(sql);
		try {
			while(resultSet.next()){
				String s = resultSet.getInt("pro_state")+"";
				result.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;		
	}

	@Override
	public ProductBean getProductBeanById(String id) {
		DBUtils dbUtils = new DBUtils();
		String sql = "select * from T_product where pro_id = '" + id +"'";
		ProductBean productBean = null;
		ResultSet resultSet = dbUtils.select(sql);
		try {
			while(resultSet.next()){
				productBean = handleData(resultSet);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return productBean;
	}

	@Override
	public int deleteById(String id) {
		DBUtils dbUtils = new DBUtils();
		String sql = "delete from T_product where pro_id = '" +id +"'";
		int result = dbUtils.update(sql);
		return result;
	}
	/**
	 * ��Beanװ������
	 * 
	 * @param resultSet
	 * @return productBean
	 */
	private ProductBean handleData(ResultSet resultSet) throws SQLException{
		ProductBean productBean = new ProductBean();
		productBean.setPro_id(resultSet.getString("pro_id"));
		productBean.setPro_name(resultSet.getString("pro_name"));
		productBean.setPro_unitprice(resultSet.getString("pro_unitprice"));
		productBean.setPro_purchase(resultSet.getString("pro_purchase"));
		productBean.setPro_type(resultSet.getString("pro_type"));
		productBean.setPro_image(resultSet.getString("pro_image"));
		productBean.setPro_describe(resultSet.getString("pro_describe"));
		productBean.setPro_date(resultSet.getString("pro_date"));
		productBean.setPro_thumbnail(resultSet.getString("pro_thumbnail"));
		productBean.setPro_inbentory(resultSet.getString("pro_inbentory"));
		productBean.setPro_state(resultSet.getString("pro_state"));
		return productBean;
	}


}
