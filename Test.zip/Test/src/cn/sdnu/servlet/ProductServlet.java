package cn.sdnu.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sdnu.service.ProductService;

public class ProductServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String action=request.getParameter("action");
		if(action==null){
			int pageIndex=Integer.parseInt(request.getParameter("pageIndex"));
			String content = request.getParameter("content");
			content=(content==null)?(String)request.getSession().getAttribute("content"):content;
			System.out.println(content);
			request.getSession().setAttribute("content", content);
			request.getSession().setAttribute("pageIndex", pageIndex);
			request.getSession().setAttribute("num", new ProductService().countPro(content));
			request.setAttribute("list", new ProductService().findAllPro(pageIndex,content));
			request.getRequestDispatcher("liebiao.jsp").forward(request, response);	
		}else{
			if(action.equals("detail")){
				String id = request.getParameter("id");
				request.setAttribute("product", new ProductService().findItemById(id));
				request.getRequestDispatcher("xiangqing.jsp").forward(request, response);
			}
		}
	}
}
