package cn.sdnu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sdnu.domin.User;
import cn.sdnu.service.UserService;

public class RegisterServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String tel =request.getParameter("tel");
		String verify = request.getParameter("verifyCode");
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setUser_mobile(tel);
		user.setVerifyCode(verify);
		String sessionverify = (String) request.getSession().getAttribute("session_code");
		user.setSessionverify(sessionverify);
	
		String result = new UserService().register(user);
		if("注册成功！".equals(result)){
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}else{
			request.setAttribute("msg", result);
			request.getRequestDispatcher("register.jsp").forward(request, response);
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
