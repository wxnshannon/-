package cn.sdnu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sdnu.dao.UserDao;
import cn.sdnu.domin.User;
import cn.sdnu.service.UserService;

public class AlterInfoServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		}


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		User users = new User();
		users.setUser_soname(username);
		users.setUser_mobile(request.getParameter("phone"));
		users.setPassword(password);
		users.setUser_sex(request.getParameter("sex"));
		users.setUser_address(request.getParameter("adress"));

		User user = (User) request.getSession().getAttribute("user");
		String user_acc =user.getUser_acc();
		String result = new UserService().Alter(users, user_acc);
		if("更新成功！".equals(result)){
			User userinfo=UserDao.UserSelect(username,password);
			request.getSession().setAttribute("user", userinfo);
			request.getRequestDispatcher("self_info.jsp").forward(request, response);
		}else{
			request.setAttribute("msg", result);
			request.getRequestDispatcher("self_info.jsp").forward(request, response);
		}
	}

}
