package cn.sdnu.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sdnu.dao.UserDao;
import cn.sdnu.domin.User;
import cn.sdnu.service.UserService;

public class LoginServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		User userinfo = new User();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String verify = request.getParameter("verifyCode");
		
		
		String sessionverify = (String) request.getSession().getAttribute("session_code");//(String) request.getSession().getAttribute("session_code");
		if(verify.equalsIgnoreCase(sessionverify)){
			Boolean b = new UserService().login(username, password);
			if (b == null) { // 数据库错误
				request.setAttribute("msg", "数据库异常！");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			} else if (!b) { // 登录失败
				request.setAttribute("msg", "用户名或密码错误！");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			} else { // 登陆成功
				request.getSession().setAttribute("username", username);
				userinfo=UserDao.UserSelect(username,password);
				request.getSession().setAttribute("user", userinfo);
				response.sendRedirect("primary.jsp");
			}
		
		}
		else{
			request.setAttribute("msg", "验证码错误！");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
