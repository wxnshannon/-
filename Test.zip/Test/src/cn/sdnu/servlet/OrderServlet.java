package cn.sdnu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sdnu.domin.User;
import cn.sdnu.service.OrderService;

public class OrderServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {doPost(request, response);}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		OrderService orderService = new OrderService();
		String action=request.getParameter("action");
		if(action==null){
			User user = (User) request.getSession().getAttribute("user");
			request.setAttribute("list", orderService.findAllOrder(user.getUser_acc()));
			request.getRequestDispatcher("dingdan.jsp").forward(request, response);
		}else{
			if(action.equals("detail")){
				request.setAttribute("list", orderService.findDetailById(request.getParameter("id")));
				request.setAttribute("info", orderService.countDetail(request.getParameter("id")));
				request.getRequestDispatcher("dingdanxiangxi.jsp").forward(request, response);
			}
		}
	}
}
