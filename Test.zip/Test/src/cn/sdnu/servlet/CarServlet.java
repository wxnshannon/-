package cn.sdnu.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.sdnu.domin.CarBean;
import cn.sdnu.domin.ProductBean;
import cn.sdnu.domin.User;
import cn.sdnu.service.CarService;
import cn.sdnu.service.ProductService;

public class CarServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		CarService carService=new CarService();
		User user = (User) request.getSession().getAttribute("user");
		String user_acc = user.getUser_acc();
		String action=request.getParameter("action");
		String id = request.getParameter("id");
		String msgString = (String) request.getSession().getAttribute("msg");
		request.getSession().removeAttribute("msg");
		if(msgString!=null){
			request.setAttribute("msg", msgString);	
		}
		
		if(action==null){
			request.setAttribute("list", carService.findAllItem(user.getUser_acc()));
			request.setAttribute("num", carService.countItem(user.getUser_acc()));
			request.getRequestDispatcher("gouwuche.jsp").forward(request, response);
		}else{
			if(action.equals("delete")){
				carService.deleteItem(id);
			}else if(action.equals("add")){
				carService.addItem(user_acc,id);
			}else if(action.equals("update")){
				carService.updateItem(id,Integer.parseInt(request.getParameter("num")));
			}else if(action.equals("pay")){
				request.getSession().setAttribute("msg", null);
				String tempString =request.getParameter("tempString");
				boolean msg = carService.payItem(tempString.substring(1));
				if(msg==false){
					request.getSession().setAttribute("msg", "库存不足，购买失败!");					
				}
			}
			response.sendRedirect("./CarServlet");
		}
	}
}
