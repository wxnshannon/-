package cn.sdnu.service;

import cn.sdnu.dao.UserDao;
import cn.sdnu.domin.User;

public class UserService {
	private UserDao userDao = new UserDao();
	
	public Boolean login(String username, String password) {
		return userDao.login(username, password);
	}

	public String register(User user) {
		/*String username = user.getUsername();
		String password = user.getPassword();
		if (username.length() < 5 || username.length() > 11) {
			return "用户名长度不符合要求";
		} else if (password.length() < 5 || password.length() > 11) {
			return "密码不符合要求";
		} // ...*/
		if(!user.getSessionverify().equalsIgnoreCase(user.getVerifyCode())){
			
			
			return "验证码错误!";
		}
		else{
		Boolean b = userDao.register(user);
		if (b == null) {
			return "数据库异常！";
		} else if (!b) {
			return "注册失败！";
		} else {
			return "注册成功！";
		}
		}
	}
	public String Alter(User user,String user_acc) {
		/*String username = user.getUsername();
		String password = user.getPassword();
		if (username.length() < 5 || username.length() > 11) {
			return "用户名长度不符合要求";
		} else if (password.length() < 5 || password.length() > 11) {
			return "密码不符合要求";
		} // ...*/
		
		Boolean b = userDao.Alter(user, user_acc);
		if (b == null) {
			return "数据库异常！";
		} else if (!b) {
			System.out.println("更新失败！");
			return "更新失败！";
		} else {
			System.out.println("更新成功！");
			return "更新成功！";
		} 
		}
	
}



