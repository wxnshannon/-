package cn.sdnu.service;

import java.util.List;

import cn.sdnu.dao.CarDao;
import cn.sdnu.dao.ProductDao;
import cn.sdnu.domin.CarBean;
import cn.sdnu.domin.ProductBean;

public class CarService {
	public List<CarBean> findAllItem(String user_acc){
		return new CarDao().findAllItem(user_acc);
	}
	public void deleteItem(String carId){
		new CarDao().deleteItem(carId);
	}
	public boolean payItem(String carId){
		return new CarDao().payItem(carId);
	}
	public int countItem(String user_acc){
		return new CarDao().countItem(user_acc);
	}
	public void addItem(String user_acc,String proId){
		new CarDao().addItem(user_acc,proId);
	}
	public void updateItem(String carId,int num){
		new CarDao().updateItem(carId,num);
	}
}
