package cn.sdnu.service;

import java.util.List;

import cn.sdnu.dao.OrderDao;
import cn.sdnu.domin.OrderBean;

public class OrderService {
	public List<OrderBean> findAllOrder(String user_acc){
		return new OrderDao().findAllOrder(user_acc);
	}
	
	public List<OrderBean> findDetailById(String order_id){
		return new OrderDao().findDetailById(order_id);
	}
	
	public String countDetail(String order_id){
		return new OrderDao().countDetail(order_id);
	}
}
