package cn.sdnu.service;

import java.util.List;

import cn.sdnu.dao.ProductDao;
import cn.sdnu.domin.ProductBean;
public class ProductService {
	public List<ProductBean> findAllPro(int pageIndex,String content){
		return new ProductDao().findAllPro(pageIndex,content);
	}
	public ProductBean findItemById(String porId){
		return new ProductDao().findItemById(porId);
	}
	public int countPro(String content){return new ProductDao().countPro(content);}
}
