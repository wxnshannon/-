package cn.sdnu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.sdnu.db.DButils;
import cn.sdnu.domin.CarBean;

public class CarDao {
	public List<CarBean> findAllItem(String user_acc){
		List<CarBean> cars = new ArrayList<CarBean>();
		String sql = "select * from shopCar_View where shopcar_useracc=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_acc);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				CarBean car = new CarBean();
				car.setShopcar_id(rs.getString(1));
				car.setShopcar_proid(rs.getString(2));
				car.setShopcar_proname(rs.getString(3));
				car.setShopcar_proiamge(rs.getString(4));
				car.setShopcar_prounitprice(rs.getInt(5));
				car.setShopcar_mount(rs.getInt(6));
				cars.add(car);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null; 
		}
		return cars;
	}

	
	public void deleteItem(String carId){
		String sql = "exec shopcarDel @shopcar_id=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, carId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public boolean payItem(String carId){
		String sql = "delete from T_shoppingcart where shopcar_id in ("+carId+")";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public int countItem(String user_acc){
		int num=0;
		String sql = "select count(*) from T_shoppingcart where shopcar_useracc=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_acc);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				num=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0; 
		}
		return num;
	}

	public void addItem(String user_acc,String proId){
		int num=0;
		String sql = "INSERT INTO [T_shoppingcart]([shopcar_useracc],[shopcar_proid],[shopcar_mount]) VALUES(?,?,1)";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_acc);
			pstmt.setString(2, proId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updateItem(String carId,int num){
		String sql = "update T_shoppingcart set shopcar_mount=? where shopcar_id=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, carId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
