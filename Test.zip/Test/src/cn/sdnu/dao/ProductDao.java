package cn.sdnu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.sdnu.db.DButils;
import cn.sdnu.domin.ProductBean;

public class ProductDao {
	public List<ProductBean> findAllPro(int pageIndex,String content){
		content=(content==null)?"":content;
		List<ProductBean> products = new ArrayList<ProductBean>();
		String sql = "exec [productList] @pageIndex=?,@content=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pageIndex);
			pstmt.setString(2, "%"+content+"%");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				ProductBean product = new ProductBean();
				product.setPro_name(rs.getString(1));
				product.setPro_describe(rs.getString(2));
				product.setPro_unitprice(rs.getString(3));
				product.setPro_image(rs.getString(4));
				product.setPro_id(rs.getString(5));
				products.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null; 
		}
		return products;
	}
	
	public ProductBean findItemById(String porId){
		ProductBean product = new ProductBean();
		String sql = "select pro_id,pro_name,pro_unitprice,pro_describe,pro_image from T_product where pro_state=1 and pro_id=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, porId);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				product.setPro_id(rs.getString(1));
				product.setPro_name(rs.getString(2));
				product.setPro_unitprice(rs.getString(3));
				product.setPro_describe(rs.getString(4));
				product.setPro_image(rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null; 
		}
		return product;
	}

	public int countPro(String content){
		content=(content==null)?"":content;
		int num=0;
		String sql = "select count(*) from T_product where pro_state=1 and pro_name like ?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+content+"%");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				num=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0; 
		}
		return num;
	}
}
