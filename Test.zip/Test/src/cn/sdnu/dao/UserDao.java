package cn.sdnu.dao;

import java.util.Random;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

import cn.sdnu.db.DButils;
import cn.sdnu.domin.User;

public class UserDao {
	public Boolean login(String username, String password) {
		/*
		CREATE PROCEDURE loginPass @name nvarchar(20)
		AS
    	select user_password from T_user WHERE user_soname = @name

		EXEC loginPass @name = N'12123'
		 * */
		String sql = "select user_password from T_user WHERE user_soname = '" + username + "'";
		//String sql = "EXEC loginPass @name = '"+username+"'";
		Connection conn = DButils.getConn();

		String upassword = "";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				upassword = rs.getString(1);
				if (upassword.trim().equals(password))
					return true; // login success
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null; // connection failed
		}
		return false; // login failed
	}
	
	public static User UserSelect(String username,String password) {
		User user = new User();
		String sql = "select * from T_user WHERE user_soname = '" + username + "' and user_password='" + password + "'" ;
		Connection conn = DButils.getConn();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				user.setUser_acc(rs.getString("user_acc"));
				user.setUsername(rs.getString("user_soname"));
				user.setUser_mobile(rs.getString("user_mobile"));
				user.setPassword(rs.getString("user_password"));
				user.setUser_sex(rs.getString("user_sex"));
				user.setUser_address(rs.getString("user_address"));
			}
		} catch (SQLException e) {
			e.printStackTrace(); 
		}

	
		return user;
	}	
	
	public Boolean register(User user) {
		String sql = "insert into T_user (user_soname,user_password,user_mobile,user_acc) values(?,?, ?,?)";
		Connection conn = DButils.getConn();
		try {// rand()*1000

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getUser_mobile());
			pstmt.setString(4, CharacterUtils.getRandomString(6));
			int res = pstmt.executeUpdate();
			if (res > 0) {
				return true; // register success
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null; // connection failed
		}
		return false; // register failed
	}
	public Boolean Alter(User users ,String user_acc) {
		String sql = "update T_user set user_soname=?,user_password=?,user_mobile=?,user_sex=?,user_address=? where user_acc='" + user_acc + "'";
		Connection conn = DButils.getConn();
		try {// rand()*1000

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, users.getUser_soname());
			pstmt.setString(2, users.getPassword());
			pstmt.setString(3, users.getUser_mobile());
			pstmt.setString(4, users.getUser_sex());
			pstmt.setString(5, users.getUser_address());
			int res = pstmt.executeUpdate();
			if (res > 0) {
				return true; // register success
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null; // connection failed
		}
		return false; // register failed
	}
	/*
	 * public Boolean findname(String username) { String sql =
	 * "select *from test2 where username=?"; Connection conn =
	 * DButils.getConn(); try { PreparedStatement pstmt =
	 * conn.prepareStatement(sql); pstmt.setString(1, username);
	 * 
	 * Boolean res = pstmt.executeQuery().first(); if (res) { return true; //
	 * register success } } catch (SQLException e) { e.printStackTrace(); return
	 * null; // connection failed } return false; // register failed }
	 */

}

class CharacterUtils {
	// 方法1:length为产生的位数
	 public static String getRandomString(int length){
	     String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	     Random random=new Random();
	     StringBuffer sb=new StringBuffer();
	     for(int i=0;i<length;i++){
	       int number=random.nextInt(62);
	       sb.append(str.charAt(number));
	     }
	     return sb.toString();
	 }
}
