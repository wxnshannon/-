package cn.sdnu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.sdnu.db.DButils;
import cn.sdnu.domin.CarBean;
import cn.sdnu.domin.OrderBean;

public class OrderDao {
	public List<OrderBean> findAllOrder(String user_acc){
		List<OrderBean> orders = new ArrayList<OrderBean>();
		String sql = "SELECT [order_id],[order_useracc],[order_date],[order_total],[order_state] FROM [T_order] where order_useracc=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_acc);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				OrderBean order = new OrderBean();
				order.setOrder_id(rs.getInt(1));
				order.setOrder_useracc(rs.getString(2));
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
				try {
					order.setOrder_date(sdf2.format(sdf1.parse(rs.getString(3))));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				order.setOrder_prototal(rs.getInt(4));
				order.setOrder_state(rs.getInt(5));
				orders.add(order);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null; 
		}
		return orders;
	}
	
	public List<OrderBean> findDetailById(String order_id){
		List<OrderBean> orders = new ArrayList<OrderBean>();
		String sql = "select * from order_pro_View where order_id=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, order_id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				OrderBean order = new OrderBean();
				order.setOrder_proiamge(rs.getString(1));
				order.setOrder_proid(rs.getString(2));
				order.setOrder_proname(rs.getString(3));
				order.setOrder_prounitprice(rs.getString(4));
				order.setOrder_pronum(rs.getInt(5));
				order.setOrder_prototal(rs.getInt(6));
				orders.add(order);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null; 
		}
		return orders;
	}
	
	public String countDetail(String order_id){
		String info="";
		String sql = "select * from countDetail_View where order_id=?";
		try {
			Connection conn = DButils.getConn();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, order_id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				int num1=rs.getInt(1);
				int num2=rs.getInt(2);
				info=num1+","+num2;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null; 
		}
		return info;
	}
}
