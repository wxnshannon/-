package cn.sdnu.domin;

public class ProductBean {
	private String pro_id; //商品ID
	private String pro_name; //商品名
	private String pro_unitprice; //单价
	private String pro_purchase; //商品进价
	private String pro_type; //商品类型
	private String pro_describe; //商品描述
	private String pro_image; //商品图像
	private String pro_date; //商品上市日期
	private String pro_thumbnail; //商品缩略图地址
	private String pro_inbentory; //商品库存
	private String pro_state; //商品状态

	public String getPro_id() {
		return pro_id;
	}
	public void setPro_id(String pro_id) {
		this.pro_id = pro_id;
	}
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public String getPro_unitprice() {
		return pro_unitprice;
	}
	public void setPro_unitprice(String pro_unitprice) {
		this.pro_unitprice = pro_unitprice;
	}
	public String getPro_purchase() {
		return pro_purchase;
	}
	public void setPro_purchase(String pro_purchase) {
		this.pro_purchase = pro_purchase;
	}
	public String getPro_type() {
		return pro_type;
	}
	public void setPro_type(String pro_type) {
		this.pro_type = pro_type;
	}
	public String getPro_describe() {
		return pro_describe;
	}
	public void setPro_describe(String pro_describe) {
		this.pro_describe = pro_describe;
	}
	public String getPro_image() {
		return pro_image;
	}
	public void setPro_image(String pro_image) {
		this.pro_image = pro_image;
	}
	public String getPro_date() {
		return pro_date;
	}
	public void setPro_date(String pro_date) {
		this.pro_date = pro_date;
	}
	public String getPro_thumbnail() {
		return pro_thumbnail;
	}
	public void setPro_thumbnail(String pro_thumbnail) {
		this.pro_thumbnail = pro_thumbnail;
	}
	public String getPro_inbentory() {
		return pro_inbentory;
	}
	public void setPro_inbentory(String pro_inbentory) {
		this.pro_inbentory = pro_inbentory;
	}
	public String getPro_state() {
		return pro_state;
	}
	public void setPro_state(String pro_state) {
		this.pro_state = pro_state;
	}
	
}
