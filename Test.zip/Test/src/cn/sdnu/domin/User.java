package cn.sdnu.domin;

import java.io.Serializable;
import java.util.Date;
/**
* @author gacl
* �û�ʵ����
*/
public class User implements Serializable {

// �û�ID
private String username;
private String user_acc;


// �û���
private String password;
private String user_mobile;

private String verifyCode;
private String user_sex;
private String user_soname;
public String getUser_soname() {
	return user_soname;
}
public void setUser_soname(String user_soname) {
	this.user_soname = user_soname;
}
public String getUser_sex() {
	return user_sex;
}
public void setUser_sex(String user_sex) {
	this.user_sex = user_sex;
}
public String getUser_address() {
	return user_address;
}
public void setUser_address(String user_address) {
	this.user_address = user_address;
}
private String user_address;
public String getUser_acc() {
	return user_acc;
}
public void setUser_acc(String user_acc) {  
	this.user_acc = user_acc;
}
private String sessionverify;
public String getSessionverify() {
	return sessionverify;
}
public void setSessionverify(String sessionverify) {
	this.sessionverify = sessionverify;
}
public String getVerifyCode() {
	return verifyCode;
}
public void setVerifyCode(String verifyCode) {
	this.verifyCode = verifyCode;
}
public String getUser_mobile() {
	return user_mobile;
}
public void setUser_mobile(String user_mobile) {
	this.user_mobile = user_mobile;
}
// �û�����
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}


}