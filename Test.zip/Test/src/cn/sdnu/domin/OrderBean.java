package cn.sdnu.domin;

public class OrderBean {
	private int order_id;
	private String order_useracc;
	private String order_date;
	private String order_total;
	private String order_profit;
	private int order_state;
	private String order_proid;
	private String order_proname;
	private String order_proiamge;
	private String order_prounitprice;
	private int order_pronum;
	private int order_prototal;
	public String getOrder_useracc() {
		return order_useracc;
	}
	public void setOrder_useracc(String order_useracc) {
		this.order_useracc = order_useracc;
	}
	public String getOrder_date() {
		return order_date;
	}
	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}
	public String getOrder_total() {
		return order_total;
	}
	public void setOrder_total(String order_total) {
		this.order_total = order_total;
	}
	public String getOrder_profit() {
		return order_profit;
	}
	public void setOrder_profit(String order_profit) {
		this.order_profit = order_profit;
	}
	public String getOrder_proid() {
		return order_proid;
	}
	public void setOrder_proid(String order_proid) {
		this.order_proid = order_proid;
	}
	public int getOrder_pronum() {
		return order_pronum;
	}
	public void setOrder_pronum(int order_pronum) {
		this.order_pronum = order_pronum;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public int getOrder_state() {
		return order_state;
	}
	public void setOrder_state(int order_state) {
		this.order_state = order_state;
	}
	public int getOrder_prototal() {
		return order_prototal;
	}
	public void setOrder_prototal(int order_prototal) {
		this.order_prototal = order_prototal;
	}
	public String getOrder_proiamge() {
		return order_proiamge;
	}
	public void setOrder_proiamge(String order_proiamge) {
		this.order_proiamge = order_proiamge;
	}
	public String getOrder_proname() {
		return order_proname;
	}
	public void setOrder_proname(String order_proname) {
		this.order_proname = order_proname;
	}
	public String getOrder_prounitprice() {
		return order_prounitprice;
	}
	public void setOrder_prounitprice(String order_prounitprice) {
		this.order_prounitprice = order_prounitprice;
	}
}
