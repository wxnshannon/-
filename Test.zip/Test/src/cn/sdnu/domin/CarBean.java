package cn.sdnu.domin;

public class CarBean {
	private String shopcar_id;//购物车编号
	private String shopcar_useracc;//用户账号
	private String shopcar_proid;//商品编号
	private String shopcar_proname;//商品名称
	private String shopcar_proiamge;//商品图片
	private int shopcar_prounitprice;//商品单价
	private int shopcar_mount;//商品数量
	
	public String getShopcar_id() {
		return shopcar_id;
	}
	public void setShopcar_id(String shopcar_id) {
		this.shopcar_id = shopcar_id;
	}
	public String getShopcar_useracc() {
		return shopcar_useracc;
	}
	public void setShopcar_useracc(String shopcar_useracc) {
		this.shopcar_useracc = shopcar_useracc;
	}
	public String getShopcar_proid() {
		return shopcar_proid;
	}
	public void setShopcar_proid(String shopcar_proid) {
		this.shopcar_proid = shopcar_proid;
	}
	public int getShopcar_mount() {
		return shopcar_mount;
	}
	public void setShopcar_mount(int shopcar_mount) {
		this.shopcar_mount = shopcar_mount;
	}
	public int getShopcar_prounitprice() {
		return shopcar_prounitprice;
	}
	public void setShopcar_prounitprice(int shopcar_prounitprice) {
		this.shopcar_prounitprice = shopcar_prounitprice;
	}
	public String getShopcar_proname() {
		return shopcar_proname;
	}
	public void setShopcar_proname(String shopcar_proname) {
		this.shopcar_proname = shopcar_proname;
	}
	public String getShopcar_proiamge() {
		return shopcar_proiamge;
	}
	public void setShopcar_proiamge(String shopcar_proiamge) {
		this.shopcar_proiamge = shopcar_proiamge;
	}
}
