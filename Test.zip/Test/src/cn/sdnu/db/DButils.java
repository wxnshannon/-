package cn.sdnu.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DButils {
	private static String className = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static String url = "jdbc:sqlserver://localhost:1433;databaseName=Huawei";
	private static String user = "sa";//
	private static String password = "111111";
	private static Connection conn = null;
	public static DButils d1 = new DButils(className, url, user, password);
//
//	public static Connection getConn() {
//		try {
//			Class.forName(className);
//			conn = DriverManager.getConnection(url, user, password);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return conn;
//	}
	public static Connection getConn() {
		return d1.conn;
	}
	
	private DButils(String className,String url, String user, String password) {
		try {
			Class.forName(className);
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}